package com.example

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.data.TvSystemRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name and discover core hidden shortcuts`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TV Access", appName)

        val repo = TvSystemRepository(context)
        val shortcuts = repo.discoverHiddenShortcuts()
        val ids = shortcuts.map { it.id }.toSet()

        assertTrue(ids.contains("accessibility"))
        assertTrue(ids.contains("developer_options"))
        assertTrue(ids.contains("usb_wireless_debugging"))
        assertTrue(ids.contains("about_tv_build"))

        val status = repo.readSystemStatus()
        assertEquals(false, status.hasWriteSecureSettings)
    }

    @Test
    fun `main activity launches and resolves for both launcher and leanback`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = context.packageManager

        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage(context.packageName)
        }
        val leanbackIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            setPackage(context.packageName)
        }

        assertTrue(pm.queryIntentActivities(launcherIntent, 0).isNotEmpty())
        assertTrue(pm.queryIntentActivities(leanbackIntent, 0).isNotEmpty())

        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        assertNotNull(controller.get())
    }
}
