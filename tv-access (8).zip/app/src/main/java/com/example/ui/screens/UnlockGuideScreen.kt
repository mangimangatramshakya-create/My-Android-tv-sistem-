package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Adb
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.TvActionButton
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ObsidianCard
import com.example.viewmodel.TvAccessUiState

@Composable
fun UnlockGuideScreen(
    uiState: TvAccessUiState,
    adbCommand: String,
    onLaunchShortcut: (String) -> Unit,
    onCopyCommand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "Android TV Hidden Options Unlock Guide"
                } else {
                    "Android TV Hidden Options Unlock Guide"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    "Kai TV companies (Mi TV, Sony, TCL, Realme, Android TV Box) Settings menu se Accessibility, Developer Options aur USB Debugging chhupa deti hain. Neeche diye 4 steps follow karein:"
                } else {
                    "Many Android TV manufacturers hide Accessibility, Developer Options, and USB Debugging from the main TV Settings UI. Follow these exact steps:"
                }
            )
        }

        item {
            GuideStepCard(
                stepBadge = "STEP 1",
                title = if (lang == AppLanguage.HINGLISH) {
                    "Developer Options Unlock Karein (7x Build Click)"
                } else {
                    "Unlock Developer Options (7x Build Number Tap)"
                },
                body = if (lang == AppLanguage.HINGLISH) {
                    "1) Neeche 'About TV Kholein' button par OK dabayein.\n2) Scroll karke 'Android TV OS build' ya 'Build number' par jayein.\n3) Remote ka OK button lagatar 7 baar dabayein jab tak 'You are now a developer!' na dikh jaye.\n4) Wapas TV Access me aakar 'Dev Options Kholein' dabayein."
                } else {
                    "1) Click 'Open About TV' below.\n2) Scroll down to 'Android TV OS build' or 'Build number'.\n3) Press OK on your TV remote 7 times in a row until 'You are now a developer!' appears.\n4) Return to TV Access and launch Developer Options directly."
                },
                primaryButtonLabel = if (lang == AppLanguage.HINGLISH) "About TV Kholein" else "Open About TV",
                primaryIcon = Icons.Filled.Info,
                onPrimaryClick = { onLaunchShortcut("about_tv_build") },
                secondaryButtonLabel = if (lang == AppLanguage.HINGLISH) "Dev Options Kholein" else "Open Dev Options",
                secondaryIcon = Icons.Filled.DeveloperMode,
                onSecondaryClick = { onLaunchShortcut("developer_options") }
            )
        }

        item {
            GuideStepCard(
                stepBadge = "STEP 2",
                title = if (lang == AppLanguage.HINGLISH) {
                    "Missing Accessibility Options Direct Kholein"
                } else {
                    "Launch Hidden Accessibility Settings"
                },
                body = if (lang == AppLanguage.HINGLISH) {
                    "Agar TV ke Settings -> Device Preferences me Accessibility option bilkul gayab hai, tab bhi Android system ke andar Accessibility activity maujood rehti hai. Neeche button dabakar seedha Accessibility menu kholein aur kisi bhi app ko Enable/Allow karein."
                } else {
                    "Even when Accessibility is removed from TV Device Preferences, the underlying Android Accessibility screen usually remains on the device. Launch it directly below or try Full Android Settings."
                },
                primaryButtonLabel = if (lang == AppLanguage.HINGLISH) "Accessibility Kholein" else "Open Accessibility",
                primaryIcon = Icons.Filled.AccessibilityNew,
                onPrimaryClick = { onLaunchShortcut("accessibility") },
                secondaryButtonLabel = if (lang == AppLanguage.HINGLISH) "Full AOSP Settings" else "Full AOSP Settings",
                secondaryIcon = Icons.Filled.Settings,
                onSecondaryClick = { onLaunchShortcut("full_aosp_settings") }
            )
        }

        item {
            GuideStepCard(
                stepBadge = "STEP 3",
                title = if (lang == AppLanguage.HINGLISH) {
                    "USB Debugging aur Wireless Debugging ON Karein"
                } else {
                    "Enable USB Debugging & Wireless ADB"
                },
                body = if (lang == AppLanguage.HINGLISH) {
                    "Step 1 me Developer Options unlock hone ke baad, neeche 'Debugging Kholein' button dabayein. Uske andar 'USB debugging' aur (Android 11+ TV par) 'Wireless debugging' ka switch ON kar dein. Agar TV me USB port nahi hai, to Wireless Debugging best option hai."
                } else {
                    "After unlocking Developer Options in Step 1, press 'Open Debugging' below. Switch ON 'USB debugging' and (on Android 11+ TVs) 'Wireless debugging'."
                },
                primaryButtonLabel = if (lang == AppLanguage.HINGLISH) "Debugging Kholein" else "Open Debugging",
                primaryIcon = Icons.Filled.Adb,
                onPrimaryClick = { onLaunchShortcut("usb_wireless_debugging") }
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = ObsidianCard
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatusPill(label = "STEP 4 • POWER MODE", tone = StatusTone.INFO)
                    Text(
                        text = if (lang == AppLanguage.HINGLISH) {
                            "Ek Click Direct Toggle Unlock (Phone ya PC se ADB)"
                        } else {
                            "Unlock One-Click Direct Toggles via ADB (Optional)"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (lang == AppLanguage.HINGLISH) {
                            "Android security ke karan koi bhi app bina permission ke USB Debugging ya Accessibility silently ON nahi kar sakta. Ek baar apne Phone (same Wi-Fi par) ya Laptop se yeh command chalane par TV Access ke andar seedha ON/OFF switches kaam karne lagenge:"
                        } else {
                            "Android OS restricts background changes to secure settings. Run this one-time command from a PC or a phone ADB utility on the same Wi-Fi network to enable direct in-app toggles:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = Color(0xFF090D14)
                    ) {
                        Text(
                            text = adbCommand,
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        )
                    }
                    TvActionButton(
                        label = if (lang == AppLanguage.HINGLISH) "ADB Command Copy Karein" else "Copy ADB Command",
                        icon = Icons.Filled.ContentCopy,
                        onClick = {
                            clipboardManager.setText(AnnotatedString(adbCommand))
                            onCopyCommand()
                        },
                        testTag = "btn_guide_copy_adb",
                        isPrimary = true
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideStepCard(
    stepBadge: String,
    title: String,
    body: String,
    primaryButtonLabel: String,
    primaryIcon: ImageVector,
    onPrimaryClick: () -> Unit,
    secondaryButtonLabel: String? = null,
    secondaryIcon: ImageVector? = null,
    onSecondaryClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = ObsidianCard
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatusPill(label = stepBadge, tone = StatusTone.INFO)
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TvActionButton(
                    label = primaryButtonLabel,
                    icon = primaryIcon,
                    onClick = onPrimaryClick,
                    testTag = "guide_${stepBadge.lowercase().replace(' ', '_')}_primary",
                    isPrimary = true
                )
                if (secondaryButtonLabel != null && secondaryIcon != null && onSecondaryClick != null) {
                    TvActionButton(
                        label = secondaryButtonLabel,
                        icon = secondaryIcon,
                        onClick = onSecondaryClick,
                        testTag = "guide_${stepBadge.lowercase().replace(' ', '_')}_secondary",
                        isPrimary = false
                    )
                }
            }
        }
    }
}
