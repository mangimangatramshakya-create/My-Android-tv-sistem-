package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.SettingsApplications
import androidx.compose.material.icons.filled.ToggleOff
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.HiddenSettingShortcut
import com.example.model.ShortcutCategory
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.TvFocusCard
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGrant
import com.example.ui.theme.TextMuted
import com.example.viewmodel.TvAccessUiState

@Composable
fun HiddenSettingsScreen(
    uiState: TvAccessUiState,
    onLaunchShortcut: (HiddenSettingShortcut) -> Unit,
    onToggleAccessibilityService: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val services = uiState.systemStatus.installedAccessibilityServices
    val grouped = ShortcutCategory.entries.map { cat ->
        cat to uiState.shortcuts.filter { it.category == cat }
    }.filter { it.second.isNotEmpty() }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "Hidden Android TV Settings Launcher"
                } else {
                    "Hidden Android TV Settings Launcher"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    "Har card aapke TV firmware me check karta hai ki chhupi hui system screen maujood hai ya nahi. OK dabakar seedha kholein."
                } else {
                    "Every launcher checks your TV firmware for the underlying Android Settings activity so you can open menus hidden by your TV OEM."
                }
            )
        }

        grouped.forEach { (category, items) ->
            item(key = "header_${category.name}") {
                Text(
                    text = category.title.resolve(lang),
                    style = MaterialTheme.typography.titleLarge,
                    color = ElectricCyan
                )
            }

            item(key = "grid_${category.name}") {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val columns = if (maxWidth >= 700.dp) 2 else 1
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items.chunked(columns).forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                rowItems.forEach { shortcut ->
                                    ShortcutLauncherCard(
                                        shortcut = shortcut,
                                        lang = lang,
                                        onClick = { onLaunchShortcut(shortcut) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (rowItems.size < columns) {
                                    repeat(columns - rowItems.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "Installed Accessibility Services (${services.size})"
                } else {
                    "Installed Accessibility Services (${services.size})"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    if (uiState.systemStatus.hasWriteSecureSettings) {
                        "Power Mode active hai — kisi bhi service par OK dabakar seedha ON/OFF karein."
                    } else {
                        "Yahan TV me maujood sabhi Accessibility services dikh rahi hain. Enable karne ke liye click karke Accessibility settings kholein."
                    }
                } else {
                    if (uiState.systemStatus.hasWriteSecureSettings) {
                        "Power Mode is active — click any service below to toggle it directly."
                    } else {
                        "All Accessibility services detected on this TV. Click any item to open Accessibility Settings."
                    }
                }
            )
        }

        if (services.isEmpty()) {
            item {
                TvFocusCard(
                    onClick = {
                        uiState.shortcuts.find { it.id == "accessibility" }?.let(onLaunchShortcut)
                    },
                    testTag = "empty_a11y_services_card",
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AccessibilityNew,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = if (lang == AppLanguage.HINGLISH) {
                                    "Koi external Accessibility service install nahi mili"
                                } else {
                                    "No third-party Accessibility services detected"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (lang == AppLanguage.HINGLISH) {
                                    "Fir bhi system Accessibility screen kholne ke liye yahan OK dabayein."
                                } else {
                                    "Click here to launch system Accessibility settings anyway."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    services.forEach { service ->
                        TvFocusCard(
                            onClick = { onToggleAccessibilityService(service.id, service.isEnabled) },
                            testTag = "a11y_service_${service.packageName}",
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = service.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = service.id,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    StatusPill(
                                        label = if (service.isEnabled) "ENABLED" else "DISABLED",
                                        tone = if (service.isEnabled) StatusTone.GRANTED else StatusTone.WARNING
                                    )
                                    Icon(
                                        imageVector = if (service.isEnabled) Icons.Filled.ToggleOn else Icons.Filled.ToggleOff,
                                        contentDescription = service.label,
                                        tint = if (service.isEnabled) EmeraldGrant else ElectricCyan,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShortcutLauncherCard(
    shortcut: HiddenSettingShortcut,
    lang: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TvFocusCard(
        onClick = onClick,
        testTag = "shortcut_${shortcut.id}",
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Filled.SettingsApplications,
                    contentDescription = null,
                    tint = if (shortcut.isAvailable) ElectricCyan else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = shortcut.title.resolve(lang),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            StatusPill(
                label = if (shortcut.isAvailable) {
                    shortcut.resolvedPackage ?: "READY"
                } else {
                    "FALLBACK"
                },
                tone = if (shortcut.isAvailable) StatusTone.INFO else StatusTone.WARNING
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = shortcut.description.resolve(lang),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            minLines = 2
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = if (lang == AppLanguage.HINGLISH) "Screen Kholein" else "Launch Settings",
                style = MaterialTheme.typography.labelLarge,
                color = ElectricCyan,
                fontWeight = FontWeight.SemiBold
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
