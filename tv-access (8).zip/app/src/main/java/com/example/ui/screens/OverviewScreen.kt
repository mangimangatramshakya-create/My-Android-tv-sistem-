package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Adb
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.NavDestination
import com.example.model.SystemControlStatus
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.TvActionButton
import com.example.ui.components.TvFocusCard
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanContainer
import com.example.ui.theme.EmeraldGrant
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.viewmodel.TvAccessUiState

@Composable
fun OverviewScreen(
    uiState: TvAccessUiState,
    adbCommand: String,
    onRefresh: () -> Unit,
    onLaunchShortcut: (String) -> Unit,
    onToggleDeveloperOptions: () -> Unit,
    onToggleUsbDebugging: () -> Unit,
    onToggleWirelessDebugging: () -> Unit,
    onNavigate: (NavDestination) -> Unit,
    onCopyCommand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val status = uiState.systemStatus
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            HeroBannerCard(
                status = status,
                lang = lang,
                onRefresh = onRefresh,
                onOpenGuide = { onNavigate(NavDestination.UNLOCK_GUIDE) }
            )
        }

        item {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "3 Main TV Options — Direct Access & Status"
                } else {
                    "3 Core TV Controls — Direct Access & Status"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    "Agar TV Settings me yeh options nahi dikh rahe hain, to neeche diye cards se seedha system screen kholein ya enable karein."
                } else {
                    "Even when hidden from your Android TV Settings menu, launch these underlying system panels directly or toggle via ADB power mode."
                }
            )
        }

        item {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val isWide = maxWidth >= 680.dp
                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CorePillarCard(
                            modifier = Modifier.weight(1f),
                            testTag = "card_accessibility_pillar",
                            icon = Icons.Filled.AccessibilityNew,
                            title = "Accessibility",
                            isEnabled = status.accessibilityEnabled,
                            statusLabel = if (status.accessibilityEnabled) {
                                if (lang == AppLanguage.HINGLISH) "ON (${status.installedAccessibilityServices.count { it.isEnabled }} Active)" else "ENABLED (${status.installedAccessibilityServices.count { it.isEnabled }} Active)"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "OFF / Inactive" else "OFF / Inactive"
                            },
                            description = if (lang == AppLanguage.HINGLISH) {
                                "TV me chhupa Accessibility menu kholein aur services ko Allow / Enable karein."
                            } else {
                                "Open hidden TV Accessibility settings and manage installed services."
                            },
                            actionLabel = if (lang == AppLanguage.HINGLISH) "Accessibility Kholein" else "Open Accessibility",
                            onClick = { onLaunchShortcut("accessibility") }
                        )

                        CorePillarCard(
                            modifier = Modifier.weight(1f),
                            testTag = "card_usb_debugging_pillar",
                            icon = Icons.Filled.Adb,
                            title = "USB Debugging",
                            isEnabled = status.usbDebuggingEnabled,
                            statusLabel = if (status.usbDebuggingEnabled) {
                                if (lang == AppLanguage.HINGLISH) "ADB ON" else "ADB ENABLED"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "OFF / Locked" else "OFF"
                            },
                            description = if (lang == AppLanguage.HINGLISH) {
                                if (status.hasWriteSecureSettings) {
                                    "Power Mode active! Click karke seedha USB Debugging ON/OFF karein."
                                } else {
                                    "Seedha Debugging / Wireless ADB screen kholein aur USB Debugging ON karein."
                                }
                            } else {
                                if (status.hasWriteSecureSettings) {
                                    "Power Mode active! Click to toggle USB Debugging directly."
                                } else {
                                    "Launch hidden Debugging / Wireless ADB settings to enable USB Debugging."
                                }
                            },
                            actionLabel = if (status.hasWriteSecureSettings) {
                                if (status.usbDebuggingEnabled) "Turn OFF ADB" else "Enable USB Debugging"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "Debugging Kholein" else "Open Debugging"
                            },
                            onClick = onToggleUsbDebugging
                        )

                        CorePillarCard(
                            modifier = Modifier.weight(1f),
                            testTag = "card_dev_options_pillar",
                            icon = Icons.Filled.DeveloperMode,
                            title = "Developer Options",
                            isEnabled = status.developerOptionsEnabled,
                            statusLabel = if (status.developerOptionsEnabled) {
                                if (lang == AppLanguage.HINGLISH) "UNLOCKED & ON" else "UNLOCKED & ON"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "HIDDEN / OFF" else "LOCKED / OFF"
                            },
                            description = if (lang == AppLanguage.HINGLISH) {
                                if (status.hasWriteSecureSettings) {
                                    "Power Mode active! Click karke Developer Options toggle karein."
                                } else {
                                    "Developer Options kholein. Pehli baar unlock ke liye 'About TV' me Build par 7x click karein."
                                }
                            } else {
                                if (status.hasWriteSecureSettings) {
                                    "Power Mode active! Click to toggle Developer Options directly."
                                } else {
                                    "Open Developer Options directly, or unlock first via 7 clicks in About TV."
                                }
                            },
                            actionLabel = if (status.hasWriteSecureSettings) {
                                if (status.developerOptionsEnabled) "Disable Dev Options" else "Enable Dev Options"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "Dev Options Kholein" else "Open Dev Options"
                            },
                            onClick = onToggleDeveloperOptions
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CorePillarCard(
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "card_accessibility_pillar",
                            icon = Icons.Filled.AccessibilityNew,
                            title = "Accessibility",
                            isEnabled = status.accessibilityEnabled,
                            statusLabel = if (status.accessibilityEnabled) "ON" else "OFF",
                            description = if (lang == AppLanguage.HINGLISH) {
                                "TV me chhupa Accessibility menu kholein aur services ko Allow / Enable karein."
                            } else {
                                "Open hidden TV Accessibility settings and manage installed services."
                            },
                            actionLabel = if (lang == AppLanguage.HINGLISH) "Accessibility Kholein" else "Open Accessibility",
                            onClick = { onLaunchShortcut("accessibility") }
                        )
                        CorePillarCard(
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "card_usb_debugging_pillar",
                            icon = Icons.Filled.Adb,
                            title = "USB Debugging",
                            isEnabled = status.usbDebuggingEnabled,
                            statusLabel = if (status.usbDebuggingEnabled) "ON" else "OFF",
                            description = if (lang == AppLanguage.HINGLISH) {
                                "Seedha Debugging / Wireless ADB screen kholein aur USB Debugging ON karein."
                            } else {
                                "Launch hidden Debugging settings to turn on USB Debugging."
                            },
                            actionLabel = if (status.hasWriteSecureSettings) {
                                if (status.usbDebuggingEnabled) "Turn OFF ADB" else "Enable USB Debugging"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "Debugging Kholein" else "Open Debugging"
                            },
                            onClick = onToggleUsbDebugging
                        )
                        CorePillarCard(
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "card_dev_options_pillar",
                            icon = Icons.Filled.DeveloperMode,
                            title = "Developer Options",
                            isEnabled = status.developerOptionsEnabled,
                            statusLabel = if (status.developerOptionsEnabled) "ON" else "OFF",
                            description = if (lang == AppLanguage.HINGLISH) {
                                "Developer Options kholein. Pehli baar unlock ke liye About TV me Build par 7x click karein."
                            } else {
                                "Open Developer Options directly, or unlock first via 7 clicks in About TV."
                            },
                            actionLabel = if (status.hasWriteSecureSettings) {
                                if (status.developerOptionsEnabled) "Disable Dev Options" else "Enable Dev Options"
                            } else {
                                if (lang == AppLanguage.HINGLISH) "Dev Options Kholein" else "Open Dev Options"
                            },
                            onClick = onToggleDeveloperOptions
                        )
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "Quick Unlock & All-Permission Shortcuts"
                } else {
                    "Quick Unlock & All-Permission Shortcuts"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    "TV remote se OK dabakar kisi bhi hidden permission screen par seedha jayein."
                } else {
                    "Use your TV remote OK button to jump straight into hidden permission managers."
                }
            )
        }

        item {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val columns = if (maxWidth >= 680.dp) 3 else 1
                val quickItems = listOf(
                    Triple(
                        "about_tv_build",
                        Icons.Filled.Info,
                        if (lang == AppLanguage.HINGLISH) {
                            "About TV (7x Build Click)" to "Developer Options unlock karne ke liye Build par 7 baar OK dabayein"
                        } else {
                            "About TV (Build x7)" to "Press OK 7 times on OS Build to unlock Developer Options"
                        }
                    ),
                    Triple(
                        "full_aosp_settings",
                        Icons.Filled.Settings,
                        if (lang == AppLanguage.HINGLISH) {
                            "Full Android Settings" to "TV menu se gayab poora AOSP Settings kholein"
                        } else {
                            "Full Android Settings" to "Launch full Android Settings hidden by TV launcher"
                        }
                    ),
                    Triple(
                        "overlay_access",
                        Icons.Filled.Layers,
                        if (lang == AppLanguage.HINGLISH) {
                            "Display Over Other Apps" to "Floating overlay permissions enable/allow karein"
                        } else {
                            "Display Over Other Apps" to "Manage floating overlay permissions for TV apps"
                        }
                    ),
                    Triple(
                        "write_system_settings",
                        Icons.Filled.Build,
                        if (lang == AppLanguage.HINGLISH) {
                            "Modify System Settings" to "Apps ko system settings badalne ki permission dein"
                        } else {
                            "Modify System Settings" to "Allow apps to modify system settings"
                        }
                    ),
                    Triple(
                        "manage_all_apps",
                        Icons.Filled.Apps,
                        if (lang == AppLanguage.HINGLISH) {
                            "All Apps Permissions" to "Kisi bhi app ki camera, mic, storage permissions allow karein"
                        } else {
                            "All Apps Permissions" to "Inspect and grant runtime permissions for any app"
                        }
                    ),
                    Triple(
                        "unknown_apps",
                        Icons.Filled.Security,
                        if (lang == AppLanguage.HINGLISH) {
                            "Install Unknown Apps" to "File manager / downloader ke liye APK install allow karein"
                        } else {
                            "Install Unknown Apps" to "Allow TV file managers to install APK packages"
                        }
                    )
                )

                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    quickItems.chunked(columns).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowItems.forEach { (id, icon, texts) ->
                                QuickLauncherCard(
                                    modifier = Modifier.weight(1f),
                                    testTag = "quick_$id",
                                    icon = icon,
                                    title = texts.first,
                                    subtitle = texts.second,
                                    onClick = { onLaunchShortcut(id) }
                                )
                            }
                            if (rowItems.size < columns) {
                                repeat(columns - rowItems.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            PowerModeAdbCard(
                status = status,
                lang = lang,
                adbCommand = adbCommand,
                onCopyCommand = {
                    clipboardManager.setText(AnnotatedString(adbCommand))
                    onCopyCommand()
                },
                onToggleWirelessAdb = onToggleWirelessDebugging,
                onOpenGuide = { onNavigate(NavDestination.UNLOCK_GUIDE) }
            )
        }
    }
}

@Composable
private fun HeroBannerCard(
    status: SystemControlStatus,
    lang: AppLanguage,
    onRefresh: () -> Unit,
    onOpenGuide: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = ObsidianCard
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_tv_banner),
                contentDescription = stringResource(id = R.string.banner_desc),
                contentScale = ContentScale.Crop,
                alpha = 0.35f,
                modifier = Modifier.matchParentSize()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                ObsidianBg.copy(alpha = 0.96f),
                                ObsidianCard.copy(alpha = 0.85f),
                                ObsidianBg.copy(alpha = 0.7f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPill(
                        label = "${status.deviceModel} • Android ${status.androidVersion} (API ${status.sdkInt})",
                        tone = StatusTone.INFO
                    )
                    StatusPill(
                        label = if (status.hasWriteSecureSettings) {
                            "POWER MODE ACTIVE"
                        } else if (status.isTvDevice) {
                            "ANDROID TV MODE"
                        } else {
                            "STANDARD MODE"
                        },
                        tone = if (status.hasWriteSecureSettings) StatusTone.GRANTED else StatusTone.WARNING
                    )
                }

                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Android TV Permission & Hidden Settings Hub"
                    } else {
                        "Android TV Permission & Hidden Settings Hub"
                    },
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Agar aapke Android TV me Accessibility, USB Debugging ya Developer Options menu me nahi mil rahe, to yahan se seedha chhupe system menus kholein aur sabhi app permissions manage karein."
                    } else {
                        "Access hidden Accessibility, USB Debugging, Developer Options, and Special App Permissions on Android TVs where manufacturers hide them from the main Settings menu."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TvActionButton(
                        label = if (lang == AppLanguage.HINGLISH) "Status Refresh Karein" else "Refresh Live Status",
                        icon = Icons.Filled.Refresh,
                        onClick = onRefresh,
                        testTag = "btn_refresh_status",
                        isPrimary = true
                    )
                    TvActionButton(
                        label = if (lang == AppLanguage.HINGLISH) "Unlock Guide Dekhein" else "How to Unlock TV",
                        icon = Icons.Filled.Info,
                        onClick = onOpenGuide,
                        testTag = "btn_open_guide",
                        isPrimary = false
                    )
                }
            }
        }
    }
}

@Composable
private fun CorePillarCard(
    icon: ImageVector,
    title: String,
    isEnabled: Boolean,
    statusLabel: String,
    description: String,
    actionLabel: String,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TvFocusCard(
        onClick = onClick,
        testTag = testTag,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isEnabled) EmeraldGrant.copy(alpha = 0.18f)
                        else ElectricCyanContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isEnabled) EmeraldGrant else ElectricCyan,
                    modifier = Modifier.size(24.dp)
                )
            }
            StatusPill(
                label = statusLabel,
                tone = if (isEnabled) StatusTone.GRANTED else StatusTone.WARNING
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            minLines = 2
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = ElectricCyan,
                fontWeight = FontWeight.SemiBold
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun QuickLauncherCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TvFocusCard(
        onClick = onClick,
        testTag = testTag,
        modifier = modifier,
        contentPadding = PaddingValues(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ObsidianCardElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = ElectricCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun PowerModeAdbCard(
    status: SystemControlStatus,
    lang: AppLanguage,
    adbCommand: String,
    onCopyCommand: () -> Unit,
    onToggleWirelessAdb: () -> Unit,
    onOpenGuide: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = ObsidianCard,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Terminal,
                        contentDescription = null,
                        tint = if (status.hasWriteSecureSettings) EmeraldGrant else AmberWarn
                    )
                    Text(
                        text = if (lang == AppLanguage.HINGLISH) {
                            "Direct Toggle Power Mode (WRITE_SECURE_SETTINGS)"
                        } else {
                            "Direct Toggle Power Mode (WRITE_SECURE_SETTINGS)"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                StatusPill(
                    label = if (status.hasWriteSecureSettings) "GRANTED" else "OS LOCKED",
                    tone = if (status.hasWriteSecureSettings) StatusTone.GRANTED else StatusTone.WARNING
                )
            }

            Text(
                text = if (status.hasWriteSecureSettings) {
                    if (lang == AppLanguage.HINGLISH) {
                        "Badhai ho! Is app ko WRITE_SECURE_SETTINGS permission mili hui hai. Ab aap upar ke cards aur Hidden Settings tab se seedha Developer Options, USB Debugging, aur Accessibility services ON/OFF kar sakte hain."
                    } else {
                        "WRITE_SECURE_SETTINGS is active. You can directly toggle Developer Options, USB Debugging, Wireless ADB, and installed Accessibility services right inside this app."
                    }
                } else {
                    if (lang == AppLanguage.HINGLISH) {
                        "Android OS kisi bhi normal app ko background me USB Debugging ya Accessibility silently ON karne se rokta hai. Bina PC ke aap upar diye shortcuts se hidden TV settings seedha khol sakte hain — ya ek baar yeh ADB command chalakar Direct Toggle unlock kar sakte hain:"
                    } else {
                        "Android OS restricts apps from silently toggling USB Debugging or Accessibility without WRITE_SECURE_SETTINGS. You can still launch all hidden TV screens directly above, or run this one-time ADB command from a PC or phone ADB app to enable one-click toggles:"
                    }
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Surface(
                shape = MaterialTheme.shapes.small,
                color = Color(0xFF090D14)
            ) {
                Text(
                    text = adbCommand,
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TvActionButton(
                    label = if (lang == AppLanguage.HINGLISH) "Command Copy Karein" else "Copy ADB Command",
                    icon = Icons.Filled.ContentCopy,
                    onClick = onCopyCommand,
                    testTag = "btn_copy_adb_command",
                    isPrimary = false
                )
                if (status.wirelessDebuggingEnabled != null) {
                    TvActionButton(
                        label = if (status.wirelessDebuggingEnabled) "Wireless ADB: ON" else "Wireless ADB",
                        icon = Icons.Filled.WifiTethering,
                        onClick = onToggleWirelessAdb,
                        testTag = "btn_wireless_adb",
                        isPrimary = status.hasWriteSecureSettings
                    )
                }
                TvActionButton(
                    label = if (lang == AppLanguage.HINGLISH) "Step-by-Step Guide" else "Step-by-Step Guide",
                    icon = Icons.Filled.Info,
                    onClick = onOpenGuide,
                    testTag = "btn_adb_guide",
                    isPrimary = false
                )
            }
        }
    }
}
