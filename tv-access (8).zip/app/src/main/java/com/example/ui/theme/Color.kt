package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0B0F17)
val ObsidianSurface = Color(0xFF121824)
val ObsidianCard = Color(0xFF172030)
val ObsidianCardElevated = Color(0xFF1F2B40)
val ObsidianOutline = Color(0xFF2B3952)

val ElectricCyan = Color(0xFF22D3EE)
val ElectricCyanDim = Color(0xFF0E7490)
val ElectricCyanContainer = Color(0xFF0A3244)

val EmeraldGrant = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0A3326)

val AmberWarn = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF3A280A)

val CoralAlert = Color(0xFFFB7185)
val CoralContainer = Color(0xFF3F131E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
