package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.AppSettingsTarget
import com.example.model.AppFilter
import com.example.model.AppLanguage
import com.example.model.InstalledAppPermissionInfo
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.StatusTone
import com.example.ui.components.TvActionButton
import com.example.ui.components.TvFocusCard
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanContainer
import com.example.ui.theme.EmeraldGrant
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.TextMuted
import com.example.viewmodel.TvAccessUiState

@Composable
fun AppPermissionsScreen(
    uiState: TvAccessUiState,
    onSelectApp: (InstalledAppPermissionInfo?) -> Unit,
    onFilterChange: (AppFilter) -> Unit,
    onSearchChange: (String) -> Unit,
    onRefreshApps: () -> Unit,
    onOpenAppSettings: (String, AppSettingsTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language
    val filteredApps = remember(uiState.installedApps, uiState.appFilter, uiState.appSearchQuery) {
        val query = uiState.appSearchQuery.trim().lowercase()
        uiState.installedApps.filter { app ->
            val matchesFilter = when (uiState.appFilter) {
                AppFilter.ALL -> true
                AppFilter.TV_APPS -> app.isTvLeanbackApp
                AppFilter.NEEDS_ACCESS -> app.permissions.any { !it.isGranted }
            }
            val matchesQuery = query.isEmpty() ||
                app.appName.lowercase().contains(query) ||
                app.packageName.lowercase().contains(query)
            matchesFilter && matchesQuery
        }
    }

    var mobileShowingDetail by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader(
                title = if (lang == AppLanguage.HINGLISH) {
                    "App Permissions Inspector (${filteredApps.size})"
                } else {
                    "App Permissions Inspector (${filteredApps.size})"
                },
                subtitle = if (lang == AppLanguage.HINGLISH) {
                    "Kisi bhi app ko chunein aur uski saari permissions check ya allow karein."
                } else {
                    "Select any app to inspect granted vs denied permissions and open its system permission screen."
                },
                modifier = Modifier.weight(1f)
            )
            TvActionButton(
                label = if (lang == AppLanguage.HINGLISH) "Scan" else "Rescan",
                icon = Icons.Filled.Refresh,
                onClick = onRefreshApps,
                testTag = "btn_rescan_apps",
                isPrimary = false
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = uiState.appSearchQuery,
                onValueChange = onSearchChange,
                placeholder = {
                    Text(
                        if (lang == AppLanguage.HINGLISH) "App name ya package khojein..." else "Search app name or package..."
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = null)
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = ObsidianOutline,
                    focusedContainerColor = ObsidianCard,
                    unfocusedContainerColor = ObsidianCard
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_app_search")
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppFilter.entries.forEach { filter ->
                val selected = uiState.appFilter == filter
                FilterChip(
                    selected = selected,
                    onClick = { onFilterChange(filter) },
                    label = { Text(filter.label.resolve(lang)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricCyanContainer,
                        selectedLabelColor = ElectricCyan
                    ),
                    modifier = Modifier.testTag("filter_${filter.name}")
                )
            }
        }

        if (uiState.isLoadingApps) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = ElectricCyan)
                    Text(
                        text = if (lang == AppLanguage.HINGLISH) {
                            "TV apps aur permissions scan ho rahi hain..."
                        } else {
                            "Scanning installed apps and permissions..."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                val isSplitPane = maxWidth >= 700.dp
                if (isSplitPane) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        AppListPane(
                            apps = filteredApps,
                            selectedPackage = uiState.selectedApp?.packageName,
                            lang = lang,
                            onSelect = { onSelectApp(it) },
                            modifier = Modifier
                                .weight(0.45f)
                                .fillMaxHeight()
                        )
                        AppDetailPane(
                            app = uiState.selectedApp ?: filteredApps.firstOrNull(),
                            lang = lang,
                            showBackButton = false,
                            onBack = {},
                            onOpenAppSettings = onOpenAppSettings,
                            modifier = Modifier
                                .weight(0.55f)
                                .fillMaxHeight()
                        )
                    }
                } else {
                    if (mobileShowingDetail && uiState.selectedApp != null) {
                        BackHandler { mobileShowingDetail = false }
                        AppDetailPane(
                            app = uiState.selectedApp,
                            lang = lang,
                            showBackButton = true,
                            onBack = { mobileShowingDetail = false },
                            onOpenAppSettings = onOpenAppSettings,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        AppListPane(
                            apps = filteredApps,
                            selectedPackage = uiState.selectedApp?.packageName,
                            lang = lang,
                            onSelect = {
                                onSelectApp(it)
                                mobileShowingDetail = true
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppListPane(
    apps: List<InstalledAppPermissionInfo>,
    selectedPackage: String?,
    lang: AppLanguage,
    onSelect: (InstalledAppPermissionInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (apps.isEmpty()) {
        Surface(
            modifier = modifier,
            shape = MaterialTheme.shapes.medium,
            color = ObsidianCard
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Is filter me koi app nahi mila."
                    } else {
                        "No matching apps found."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            val isSelected = app.packageName == selectedPackage
            TvFocusCard(
                onClick = { onSelect(app) },
                testTag = "app_row_${app.packageName}",
                containerColor = if (isSelected) ObsidianCardElevated else ObsidianCard,
                contentPadding = PaddingValues(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (app.isTvLeanbackApp) Icons.Filled.Tv else Icons.Filled.Apps,
                            contentDescription = null,
                            tint = if (isSelected) ElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.appName,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.packageName,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    val allGranted = app.totalRequestedCount == 0 || app.grantedCount == app.totalRequestedCount
                    StatusPill(
                        label = "${app.grantedCount}/${app.totalRequestedCount}",
                        tone = if (allGranted) StatusTone.GRANTED else StatusTone.WARNING
                    )
                }
            }
        }
    }
}

@Composable
private fun AppDetailPane(
    app: InstalledAppPermissionInfo?,
    lang: AppLanguage,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onOpenAppSettings: (String, AppSettingsTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = ObsidianCard
    ) {
        if (app == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Permissions dekhne ke liye ek app chunein."
                    } else {
                        "Select an app to inspect its permissions."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            return@Surface
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (showBackButton) {
                item {
                    TvActionButton(
                        label = if (lang == AppLanguage.HINGLISH) "Wapas Apps List par" else "Back to App List",
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        onClick = onBack,
                        testTag = "btn_back_to_apps",
                        isPrimary = false
                    )
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricCyan
                    )
                }
            }

            item {
                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Direct Permission Screens Kholein:"
                    } else {
                        "Open System Permission Screens:"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TvActionButton(
                            label = if (lang == AppLanguage.HINGLISH) "App Info & Perms" else "App Info & Perms",
                            icon = Icons.Filled.Settings,
                            onClick = { onOpenAppSettings(app.packageName, AppSettingsTarget.APP_INFO) },
                            testTag = "btn_app_info",
                            isPrimary = true,
                            modifier = Modifier.weight(1f)
                        )
                        TvActionButton(
                            label = "Overlay Access",
                            icon = Icons.Filled.Layers,
                            onClick = { onOpenAppSettings(app.packageName, AppSettingsTarget.OVERLAY) },
                            testTag = "btn_app_overlay",
                            isPrimary = false,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TvActionButton(
                            label = "Unknown Sources",
                            icon = Icons.Filled.InstallMobile,
                            onClick = { onOpenAppSettings(app.packageName, AppSettingsTarget.UNKNOWN_SOURCES) },
                            testTag = "btn_app_unknown_sources",
                            isPrimary = false,
                            modifier = Modifier.weight(1f)
                        )
                        TvActionButton(
                            label = "All Files Access",
                            icon = Icons.Filled.FolderOpen,
                            onClick = { onOpenAppSettings(app.packageName, AppSettingsTarget.ALL_FILES) },
                            testTag = "btn_app_all_files",
                            isPrimary = false,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (lang == AppLanguage.HINGLISH) {
                        "Requested Permissions (${app.grantedCount}/${app.totalRequestedCount} Granted)"
                    } else {
                        "Requested Permissions (${app.grantedCount}/${app.totalRequestedCount} Granted)"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (app.permissions.isEmpty()) {
                item {
                    Text(
                        text = if (lang == AppLanguage.HINGLISH) {
                            "Is app ne koi special permission declare nahi ki hai."
                        } else {
                            "This app does not declare any permissions."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(app.permissions, key = { it.permissionName }) { perm ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = ObsidianCardElevated
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (perm.isGranted) Icons.Filled.CheckCircle else Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = if (perm.isGranted) EmeraldGrant else AmberWarn,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = perm.shortName,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = perm.permissionName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            StatusPill(
                                label = if (perm.isGranted) "GRANTED" else "DENIED",
                                tone = if (perm.isGranted) StatusTone.GRANTED else StatusTone.WARNING
                            )
                        }
                    }
                }
            }
        }
    }
}
