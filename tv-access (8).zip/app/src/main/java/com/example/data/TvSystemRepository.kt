package com.example.data

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.UiModeManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.content.ContextCompat
import com.example.model.AccessibilityServiceSummary
import com.example.model.AppPermissionItem
import com.example.model.BilingualText
import com.example.model.HiddenSettingShortcut
import com.example.model.InstalledAppPermissionInfo
import com.example.model.IntentCandidate
import com.example.model.ShortcutCategory
import com.example.model.SystemControlStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class AppSettingsTarget {
    APP_INFO,
    OVERLAY,
    WRITE_SETTINGS,
    UNKNOWN_SOURCES,
    ALL_FILES
}

class TvSystemRepository(private val appContext: Context) {

    fun readSystemStatus(): SystemControlStatus {
        val cr = appContext.contentResolver
        val devEnabled = runCatching {
            Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        }.getOrDefault(false)

        val adbEnabled = runCatching {
            Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1
        }.getOrDefault(false)

        val wirelessAdbEnabled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching {
                Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1
            }.getOrNull()
        } else {
            null
        }

        val accessibilityEnabled = runCatching {
            Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        }.getOrDefault(false)

        val a11yServices = readAccessibilityServices()

        val hasWriteSecure = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED

        val canOverlay = Settings.canDrawOverlays(appContext)
        val canWriteSettings = Settings.System.canWrite(appContext)

        val uiModeManager = appContext.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        val isTv = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        val model = listOfNotNull(
            Build.MANUFACTURER?.takeIf { it.isNotBlank() },
            Build.MODEL?.takeIf { it.isNotBlank() }
        ).joinToString(" ").ifBlank { "Android Device" }

        return SystemControlStatus(
            developerOptionsEnabled = devEnabled,
            usbDebuggingEnabled = adbEnabled,
            wirelessDebuggingEnabled = wirelessAdbEnabled,
            accessibilityEnabled = accessibilityEnabled,
            installedAccessibilityServices = a11yServices,
            hasWriteSecureSettings = hasWriteSecure,
            canDrawOverlays = canOverlay,
            canWriteSystemSettings = canWriteSettings,
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            sdkInt = Build.VERSION.SDK_INT,
            deviceModel = model,
            isTvDevice = isTv
        )
    }

    private fun readAccessibilityServices(): List<AccessibilityServiceSummary> {
        val am = appContext.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            ?: return emptyList()
        val pm = appContext.packageManager
        val enabledIds = runCatching {
            am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .mapNotNull { it.id }
                .toSet()
        }.getOrDefault(emptySet())

        val installed = runCatching { am.installedAccessibilityServiceList }.getOrDefault(emptyList())
        return installed.map { info ->
            val label = runCatching {
                info.resolveInfo?.loadLabel(pm)?.toString()
            }.getOrNull().orEmpty().ifBlank { info.id }
            val pkg = info.resolveInfo?.serviceInfo?.packageName ?: info.id.substringBefore('/')
            AccessibilityServiceSummary(
                id = info.id,
                label = label,
                packageName = pkg,
                isEnabled = enabledIds.contains(info.id)
            )
        }.sortedWith(compareByDescending<AccessibilityServiceSummary> { it.isEnabled }.thenBy { it.label })
    }

    fun setDeveloperOptionsEnabled(enabled: Boolean): Result<Unit> = runCatching {
        requireWriteSecure()
        if (enabled) {
            Settings.Global.putInt(
                appContext.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                1
            )
        } else {
            Settings.Global.putInt(
                appContext.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                0
            )
        }
    }

    fun setUsbDebuggingEnabled(enabled: Boolean): Result<Unit> = runCatching {
        requireWriteSecure()
        if (enabled) {
            Settings.Global.putInt(
                appContext.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                1
            )
        }
        Settings.Global.putInt(
            appContext.contentResolver,
            Settings.Global.ADB_ENABLED,
            if (enabled) 1 else 0
        )
    }

    fun setWirelessDebuggingEnabled(enabled: Boolean): Result<Unit> = runCatching {
        requireWriteSecure()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            error("Wireless Debugging requires Android 11 (API 30) or higher.")
        }
        if (enabled) {
            Settings.Global.putInt(
                appContext.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,
                1
            )
        }
        Settings.Global.putInt(
            appContext.contentResolver,
            "adb_wifi_enabled",
            if (enabled) 1 else 0
        )
    }

    fun setAccessibilityServiceEnabled(serviceId: String, enabled: Boolean): Result<Unit> = runCatching {
        requireWriteSecure()
        val cr = appContext.contentResolver
        val currentRaw = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val services = currentRaw.split(':').filter { it.isNotBlank() }.toMutableSet()
        if (enabled) {
            services.add(serviceId)
        } else {
            services.remove(serviceId)
        }
        Settings.Secure.putString(
            cr,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            services.joinToString(":")
        )
        Settings.Secure.putInt(
            cr,
            Settings.Secure.ACCESSIBILITY_ENABLED,
            if (services.isNotEmpty()) 1 else 0
        )
    }

    private fun requireWriteSecure() {
        val granted = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            error("WRITE_SECURE_SETTINGS is not granted yet. Open the settings screen directly or grant once via ADB.")
        }
    }

    fun discoverHiddenShortcuts(): List<HiddenSettingShortcut> {
        val rawShortcuts = buildShortcutDefinitions()
        return rawShortcuts.map { shortcut ->
            resolveShortcut(shortcut)
        }
    }

    private fun resolveShortcut(shortcut: HiddenSettingShortcut): HiddenSettingShortcut {
        val pm = appContext.packageManager
        for (candidate in shortcut.candidates) {
            val intent = buildIntent(candidate)
            val resolved = runCatching {
                pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            }.getOrNull()
            if (resolved != null) {
                return shortcut.copy(
                    isAvailable = true,
                    resolvedPackage = resolved.activityInfo?.packageName,
                    resolvedIntent = intent
                )
            }
        }
        return shortcut.copy(isAvailable = false)
    }

    private fun buildIntent(candidate: IntentCandidate): Intent {
        val intent = if (candidate.action != null) {
            Intent(candidate.action)
        } else {
            Intent()
        }
        if (candidate.packageName != null && candidate.className != null) {
            intent.component = ComponentName(candidate.packageName, candidate.className)
        } else if (candidate.packageName != null) {
            intent.setPackage(candidate.packageName)
        }
        if (candidate.includePackageUri) {
            intent.data = Uri.parse("package:${appContext.packageName}")
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    fun launchShortcut(shortcut: HiddenSettingShortcut): Result<String> {
        val candidatesToTry = buildList {
            shortcut.resolvedIntent?.let { add(it) }
            shortcut.candidates.forEach { add(buildIntent(it)) }
        }
        var lastError: Throwable? = null
        for (intent in candidatesToTry) {
            try {
                appContext.startActivity(intent)
                val target = shortcut.resolvedPackage
                    ?: intent.component?.packageName
                    ?: intent.action
                    ?: "System Settings"
                return Result.success(target)
            } catch (e: ActivityNotFoundException) {
                lastError = e
            } catch (e: SecurityException) {
                lastError = e
            } catch (e: Throwable) {
                lastError = e
            }
        }
        return Result.failure(
            lastError ?: IllegalStateException("This TV firmware does not expose that settings screen.")
        )
    }

    fun openAppSettings(packageName: String, target: AppSettingsTarget): Result<String> {
        val intents = when (target) {
            AppSettingsTarget.APP_INFO -> listOf(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
            AppSettingsTarget.OVERLAY -> listOf(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                },
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            )
            AppSettingsTarget.WRITE_SETTINGS -> listOf(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                },
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            )
            AppSettingsTarget.UNKNOWN_SOURCES -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                listOf(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                        data = Uri.parse("package:$packageName")
                    },
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                )
            } else {
                listOf(Intent(Settings.ACTION_SECURITY_SETTINGS))
            }
            AppSettingsTarget.ALL_FILES -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                listOf(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    },
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                )
            } else {
                listOf(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                )
            }
        }

        var lastError: Throwable? = null
        for (intent in intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                appContext.startActivity(intent)
                return Result.success(packageName)
            } catch (e: Throwable) {
                lastError = e
            }
        }
        return Result.failure(lastError ?: IllegalStateException("Settings screen unavailable on this TV."))
    }

    suspend fun loadInstalledApps(): List<InstalledAppPermissionInfo> = withContext(Dispatchers.IO) {
        val pm = appContext.packageManager
        val leanbackIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        }
        val standardIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val leanbackPackages = runCatching {
            pm.queryIntentActivities(leanbackIntent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        }.getOrDefault(emptySet())

        val launcherPackages = runCatching {
            pm.queryIntentActivities(standardIntent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        }.getOrDefault(emptySet())

        val allPackages = (leanbackPackages + launcherPackages).distinct()

        allPackages.mapNotNull { pkg ->
            runCatching {
                val pkgInfo = getPackageWithPermissions(pm, pkg) ?: return@runCatching null
                val appInfo = pkgInfo.applicationInfo
                val appName = appInfo?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                val isSystem = appInfo != null &&
                    ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0) &&
                    ((appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0)

                val requested = pkgInfo.requestedPermissions ?: emptyArray()
                val flags = pkgInfo.requestedPermissionsFlags ?: IntArray(0)

                val items = requested.mapIndexed { index, permName ->
                    val granted = index < flags.size &&
                        (flags[index] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                    val isDangerous = isDangerousPermission(pm, permName)
                    AppPermissionItem(
                        permissionName = permName,
                        shortName = permName.substringAfterLast('.'),
                        isGranted = granted,
                        isRuntimeDangerous = isDangerous
                    )
                }.sortedWith(
                    compareBy<AppPermissionItem> { it.isGranted }
                        .thenByDescending { it.isRuntimeDangerous }
                        .thenBy { it.shortName }
                )

                InstalledAppPermissionInfo(
                    packageName = pkg,
                    appName = appName,
                    isTvLeanbackApp = leanbackPackages.contains(pkg),
                    isSystemApp = isSystem,
                    grantedCount = items.count { it.isGranted },
                    totalRequestedCount = items.size,
                    permissions = items
                )
            }.getOrNull()
        }.sortedWith(
            compareByDescending<InstalledAppPermissionInfo> { it.isTvLeanbackApp }
                .thenBy { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    @Suppress("DEPRECATION")
    private fun getPackageWithPermissions(pm: PackageManager, packageName: String): PackageInfo? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
        } else {
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
        }
    }

    @Suppress("DEPRECATION")
    private fun isDangerousPermission(pm: PackageManager, permName: String): Boolean {
        return runCatching {
            val info = pm.getPermissionInfo(permName, 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.protection == android.content.pm.PermissionInfo.PROTECTION_DANGEROUS
            } else {
                (info.protectionLevel and android.content.pm.PermissionInfo.PROTECTION_MASK_BASE) ==
                    android.content.pm.PermissionInfo.PROTECTION_DANGEROUS
            }
        }.getOrDefault(false)
    }

    private fun buildShortcutDefinitions(): List<HiddenSettingShortcut> {
        val list = mutableListOf(
            HiddenSettingShortcut(
                id = "accessibility",
                category = ShortcutCategory.CORE_THREE,
                title = BilingualText(
                    en = "Accessibility Settings",
                    hi = "Accessibility Options (Hidden Menu)"
                ),
                description = BilingualText(
                    en = "Open TV Accessibility directly to enable Accessibility Services, TalkBack, Switch Access, or helper apps.",
                    hi = "TV me chhupa hua Accessibility menu seedha kholein aur kisi bhi app ki Accessibility service ON karein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_ACCESSIBILITY_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.tv.settings",
                        className = "com.android.tv.settings.accessibility.AccessibilityActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.google.android.tv.settings",
                        className = "com.android.tv.settings.accessibility.AccessibilityActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$AccessibilitySettingsActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "developer_options",
                category = ShortcutCategory.CORE_THREE,
                title = BilingualText(
                    en = "Developer Options",
                    hi = "Developer Options (Chhupa Menu)"
                ),
                description = BilingualText(
                    en = "Jump straight to Developer Options even when hidden in TV Settings. Requires Build Number x7 unlock first.",
                    hi = "Seedha Developer Options kholein. Agar na khule to pehle 'About TV' me jaakar Build Number par 7 baar OK dabayein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.tv.settings",
                        className = "com.android.tv.settings.system.DevelopmentSettingsActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.google.android.tv.settings",
                        className = "com.android.tv.settings.system.DevelopmentSettingsActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$DevelopmentSettingsDashboardActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.DevelopmentSettings"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "usb_wireless_debugging",
                category = ShortcutCategory.CORE_THREE,
                title = BilingualText(
                    en = "USB & Wireless Debugging",
                    hi = "USB aur Wireless Debugging"
                ),
                description = BilingualText(
                    en = "Open Debugging / Wireless ADB settings so you can enable USB Debugging or Wireless ADB.",
                    hi = "USB Debugging aur Wireless Debugging ON karne ke liye direct debugging screen kholein."
                ),
                candidates = listOf(
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$WirelessDebuggingActivity"
                    ),
                    IntentCandidate(action = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.tv.settings",
                        className = "com.android.tv.settings.system.DevelopmentSettingsActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$DevelopmentSettingsDashboardActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "about_tv_build",
                category = ShortcutCategory.CORE_THREE,
                title = BilingualText(
                    en = "About TV (Unlock Build x7)",
                    hi = "About TV (Build Number 7x Unlock)"
                ),
                description = BilingualText(
                    en = "Open Device Info / About TV. Press OK 7 times on 'Android TV OS build' to unlock Developer Options.",
                    hi = "Device Info / About TV kholein. 'Android TV OS build' par 7 baar OK dabane se Developer Options unlock hota hai."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_DEVICE_INFO_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.tv.settings",
                        className = "com.android.tv.settings.about.AboutActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.google.android.tv.settings",
                        className = "com.android.tv.settings.about.AboutActivity"
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$MyDeviceInfoActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "overlay_access",
                category = ShortcutCategory.SPECIAL_ACCESS,
                title = BilingualText(
                    en = "Display Over Other Apps",
                    hi = "Display Over Other Apps Permission"
                ),
                description = BilingualText(
                    en = "Allow floating windows / screen overlay permissions that many TV boxes hide from settings.",
                    hi = "Floating window aur screen overlay permission allow karne ke liye hidden list kholein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
                    IntentCandidate(
                        action = Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        includePackageUri = true
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$OverlaySettingsActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "write_system_settings",
                category = ShortcutCategory.SPECIAL_ACCESS,
                title = BilingualText(
                    en = "Modify System Settings",
                    hi = "Modify System Settings Permission"
                ),
                description = BilingualText(
                    en = "Grant apps access to modify brightness, rotation, and system settings on TV.",
                    hi = "Apps ko system settings change karne ki permission allow karein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_MANAGE_WRITE_SETTINGS),
                    IntentCandidate(
                        action = Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        includePackageUri = true
                    ),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$WriteSettingsActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "usage_access",
                category = ShortcutCategory.SPECIAL_ACCESS,
                title = BilingualText(
                    en = "Usage Data Access",
                    hi = "Usage Data Access Permission"
                ),
                description = BilingualText(
                    en = "Manage which TV apps can read app usage statistics (often hidden on Android TV).",
                    hi = "App usage stats access permission manage karein jo TV menu me nahi dikhti."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_USAGE_ACCESS_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings\$UsageAccessSettingsActivity"
                    )
                )
            ),
            HiddenSettingShortcut(
                id = "notification_access",
                category = ShortcutCategory.SPECIAL_ACCESS,
                title = BilingualText(
                    en = "Notification Listener Access",
                    hi = "Notification Access Permission"
                ),
                description = BilingualText(
                    en = "Allow TV companion or casting apps to read system notifications.",
                    hi = "Companion apps ke liye notification access allow karein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                )
            ),
            HiddenSettingShortcut(
                id = "battery_unrestricted",
                category = ShortcutCategory.SPECIAL_ACCESS,
                title = BilingualText(
                    en = "Battery / Background Optimization",
                    hi = "Background / Battery Unrestricted"
                ),
                description = BilingualText(
                    en = "Stop Android TV from killing background accessibility or utility services.",
                    hi = "Accessibility aur helper apps ko background me band hone se rokne ke liye allow karein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                )
            ),
            HiddenSettingShortcut(
                id = "manage_all_apps",
                category = ShortcutCategory.SYSTEM_UTILITIES,
                title = BilingualText(
                    en = "All Apps & Permissions Manager",
                    hi = "All Apps aur Permissions Manager"
                ),
                description = BilingualText(
                    en = "Open full Android Apps list to inspect and enable permissions for any installed app.",
                    hi = "Sabhi installed apps ki list kholein aur kisi bhi app ki permissions allow karein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS),
                    IntentCandidate(action = Settings.ACTION_APPLICATION_SETTINGS),
                    IntentCandidate(action = "android.intent.action.MANAGE_PERMISSIONS")
                )
            ),
            HiddenSettingShortcut(
                id = "full_aosp_settings",
                category = ShortcutCategory.SYSTEM_UTILITIES,
                title = BilingualText(
                    en = "Full Android Settings (AOSP)",
                    hi = "Full Android Settings (Hidden AOSP)"
                ),
                description = BilingualText(
                    en = "Launch the full hidden Android Settings dashboard instead of the stripped-down TV menu.",
                    hi = "TV ke limited settings ki jagah poora Android Settings panel kholne ki koshish karein."
                ),
                candidates = listOf(
                    IntentCandidate(
                        packageName = "com.android.settings",
                        className = "com.android.settings.Settings"
                    ),
                    IntentCandidate(action = Settings.ACTION_SETTINGS)
                )
            ),
            HiddenSettingShortcut(
                id = "security_settings",
                category = ShortcutCategory.SYSTEM_UTILITIES,
                title = BilingualText(
                    en = "Security & Unknown Sources",
                    hi = "Security aur Unknown Sources"
                ),
                description = BilingualText(
                    en = "Open Security & Restrictions settings on your Android TV.",
                    hi = "TV Security aur Restrictions menu seedha kholein."
                ),
                candidates = listOf(
                    IntentCandidate(action = Settings.ACTION_SECURITY_SETTINGS),
                    IntentCandidate(
                        packageName = "com.android.tv.settings",
                        className = "com.android.tv.settings.security.SecurityActivity"
                    )
                )
            )
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            list.add(
                5,
                HiddenSettingShortcut(
                    id = "unknown_apps",
                    category = ShortcutCategory.SPECIAL_ACCESS,
                    title = BilingualText(
                        en = "Install Unknown Apps",
                        hi = "Install Unknown Apps Permission"
                    ),
                    description = BilingualText(
                        en = "Allow specific TV file managers or browsers to install APKs.",
                        hi = "File manager ya browser ko unknown apps install karne ki permission dein."
                    ),
                    candidates = listOf(
                        IntentCandidate(action = Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES),
                        IntentCandidate(
                            action = Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            includePackageUri = true
                        )
                    )
                )
            )
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            list.add(
                6,
                HiddenSettingShortcut(
                    id = "all_files_access",
                    category = ShortcutCategory.SPECIAL_ACCESS,
                    title = BilingualText(
                        en = "All Files Access",
                        hi = "All Files Access Permission"
                    ),
                    description = BilingualText(
                        en = "Grant full storage access for TV file managers and media players.",
                        hi = "TV file manager aur media apps ke liye All Files Access allow karein."
                    ),
                    candidates = listOf(
                        IntentCandidate(action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                        IntentCandidate(
                            action = Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            includePackageUri = true
                        )
                    )
                )
            )
        }

        return list
    }
}
