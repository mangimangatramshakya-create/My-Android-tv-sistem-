package com.example.model

import android.content.Intent

enum class AppLanguage(val shortLabel: String) {
    HINGLISH("हिं / Hinglish"),
    ENGLISH("English")
}

data class BilingualText(
    val en: String,
    val hi: String
) {
    fun resolve(language: AppLanguage): String = when (language) {
        AppLanguage.ENGLISH -> en
        AppLanguage.HINGLISH -> hi
    }
}

enum class NavDestination(
    val label: BilingualText
) {
    OVERVIEW(BilingualText("Control Hub", "Control Hub")),
    HIDDEN_SETTINGS(BilingualText("Hidden Settings", "Hidden Settings")),
    APP_PERMISSIONS(BilingualText("App Permissions", "App Permissions")),
    UNLOCK_GUIDE(BilingualText("TV Unlock Guide", "TV Unlock Guide"))
}

enum class ShortcutCategory(val title: BilingualText) {
    CORE_THREE(BilingualText("Core TV Options (Hidden on Many TVs)", "Core TV Options (TV me Chhupe Options)")),
    SPECIAL_ACCESS(BilingualText("Special App Permissions", "Special App Permissions")),
    SYSTEM_UTILITIES(BilingualText("System & All Apps", "System aur All Apps"))
}

data class IntentCandidate(
    val action: String? = null,
    val packageName: String? = null,
    val className: String? = null,
    val includePackageUri: Boolean = false
)

data class HiddenSettingShortcut(
    val id: String,
    val category: ShortcutCategory,
    val title: BilingualText,
    val description: BilingualText,
    val candidates: List<IntentCandidate>,
    val isAvailable: Boolean = false,
    val resolvedPackage: String? = null,
    val resolvedIntent: Intent? = null
)

data class AccessibilityServiceSummary(
    val id: String,
    val label: String,
    val packageName: String,
    val isEnabled: Boolean
)

data class SystemControlStatus(
    val developerOptionsEnabled: Boolean = false,
    val usbDebuggingEnabled: Boolean = false,
    val wirelessDebuggingEnabled: Boolean? = null,
    val accessibilityEnabled: Boolean = false,
    val installedAccessibilityServices: List<AccessibilityServiceSummary> = emptyList(),
    val hasWriteSecureSettings: Boolean = false,
    val canDrawOverlays: Boolean = false,
    val canWriteSystemSettings: Boolean = false,
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val deviceModel: String = "",
    val isTvDevice: Boolean = false
)

data class AppPermissionItem(
    val permissionName: String,
    val shortName: String,
    val isGranted: Boolean,
    val isRuntimeDangerous: Boolean
)

data class InstalledAppPermissionInfo(
    val packageName: String,
    val appName: String,
    val isTvLeanbackApp: Boolean,
    val isSystemApp: Boolean,
    val grantedCount: Int,
    val totalRequestedCount: Int,
    val permissions: List<AppPermissionItem>
)

enum class AppFilter(val label: BilingualText) {
    ALL(BilingualText("All Apps", "Sabhi Apps")),
    TV_APPS(BilingualText("TV Apps", "TV Apps")),
    NEEDS_ACCESS(BilingualText("Has Denied Perms", "Pending Permissions"))
}

data class FeedbackBanner(
    val message: String,
    val isError: Boolean = false
)
