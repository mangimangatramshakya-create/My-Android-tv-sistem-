package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppSettingsTarget
import com.example.data.TvSystemRepository
import com.example.model.AppFilter
import com.example.model.AppLanguage
import com.example.model.FeedbackBanner
import com.example.model.HiddenSettingShortcut
import com.example.model.InstalledAppPermissionInfo
import com.example.model.NavDestination
import com.example.model.SystemControlStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TvAccessUiState(
    val destination: NavDestination = NavDestination.OVERVIEW,
    val language: AppLanguage = AppLanguage.HINGLISH,
    val systemStatus: SystemControlStatus = SystemControlStatus(),
    val shortcuts: List<HiddenSettingShortcut> = emptyList(),
    val installedApps: List<InstalledAppPermissionInfo> = emptyList(),
    val selectedApp: InstalledAppPermissionInfo? = null,
    val appFilter: AppFilter = AppFilter.ALL,
    val appSearchQuery: String = "",
    val isLoadingApps: Boolean = true,
    val feedback: FeedbackBanner? = null
)

class TvAccessViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TvSystemRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(TvAccessUiState())
    val uiState: StateFlow<TvAccessUiState> = _uiState.asStateFlow()

    val adbGrantCommand: String =
        "adb shell pm grant ${application.packageName} android.permission.WRITE_SECURE_SETTINGS"

    init {
        refreshSystemState()
        refreshInstalledApps()
    }

    fun selectDestination(destination: NavDestination) {
        _uiState.update { it.copy(destination = destination) }
    }

    fun toggleLanguage() {
        _uiState.update { state ->
            val next = if (state.language == AppLanguage.HINGLISH) {
                AppLanguage.ENGLISH
            } else {
                AppLanguage.HINGLISH
            }
            state.copy(language = next)
        }
    }

    fun refreshSystemState() {
        val status = repository.readSystemStatus()
        val shortcuts = repository.discoverHiddenShortcuts()
        _uiState.update { state ->
            state.copy(
                systemStatus = status,
                shortcuts = shortcuts
            )
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            val apps = repository.loadInstalledApps()
            _uiState.update { state ->
                val updatedSelection = state.selectedApp?.let { current ->
                    apps.find { it.packageName == current.packageName }
                } ?: apps.firstOrNull()
                state.copy(
                    installedApps = apps,
                    selectedApp = updatedSelection,
                    isLoadingApps = false
                )
            }
        }
    }

    fun selectApp(app: InstalledAppPermissionInfo?) {
        _uiState.update { it.copy(selectedApp = app) }
    }

    fun setAppFilter(filter: AppFilter) {
        _uiState.update { it.copy(appFilter = filter) }
    }

    fun setAppSearchQuery(query: String) {
        _uiState.update { it.copy(appSearchQuery = query) }
    }

    fun launchShortcutById(id: String) {
        val shortcut = _uiState.value.shortcuts.find { it.id == id }
        if (shortcut != null) {
            launchShortcut(shortcut)
        } else {
            showFeedback(
                en = "Settings shortcut not found.",
                hi = "Settings shortcut nahi mila.",
                isError = true
            )
        }
    }

    fun launchShortcut(shortcut: HiddenSettingShortcut) {
        val lang = _uiState.value.language
        repository.launchShortcut(shortcut)
            .onSuccess { targetPkg ->
                _uiState.update {
                    it.copy(
                        feedback = FeedbackBanner(
                            message = when (lang) {
                                AppLanguage.ENGLISH -> "Opened ${shortcut.title.en} ($targetPkg)"
                                AppLanguage.HINGLISH -> "${shortcut.title.hi} khul gaya ($targetPkg)"
                            },
                            isError = false
                        )
                    )
                }
            }
            .onFailure {
                _uiState.update {
                    it.copy(
                        feedback = FeedbackBanner(
                            message = when (lang) {
                                AppLanguage.ENGLISH -> "This TV firmware blocked '${shortcut.title.en}'. Try 'About TV' (7x Build) or 'Full Android Settings'."
                                AppLanguage.HINGLISH -> "Aapke TV firmware ne '${shortcut.title.hi}' block kiya hai. 'About TV' (7x Build) ya 'Full Android Settings' try karein."
                            },
                            isError = true
                        )
                    )
                }
            }
    }

    fun toggleDeveloperOptions() {
        val current = _uiState.value.systemStatus.developerOptionsEnabled
        if (!_uiState.value.systemStatus.hasWriteSecureSettings) {
            launchShortcutById("developer_options")
            return
        }
        repository.setDeveloperOptionsEnabled(!current)
            .onSuccess {
                refreshSystemState()
                showFeedback(
                    en = if (!current) "Developer Options enabled." else "Developer Options disabled.",
                    hi = if (!current) "Developer Options ON ho gaya." else "Developer Options OFF ho gaya."
                )
            }
            .onFailure { err ->
                showFeedback(
                    en = err.message ?: "Unable to toggle Developer Options.",
                    hi = err.message ?: "Developer Options badal nahi paya.",
                    isError = true
                )
            }
    }

    fun toggleUsbDebugging() {
        val current = _uiState.value.systemStatus.usbDebuggingEnabled
        if (!_uiState.value.systemStatus.hasWriteSecureSettings) {
            launchShortcutById("usb_wireless_debugging")
            return
        }
        repository.setUsbDebuggingEnabled(!current)
            .onSuccess {
                refreshSystemState()
                showFeedback(
                    en = if (!current) "USB Debugging enabled." else "USB Debugging disabled.",
                    hi = if (!current) "USB Debugging ON ho gaya." else "USB Debugging OFF ho gaya."
                )
            }
            .onFailure { err ->
                showFeedback(
                    en = err.message ?: "Unable to toggle USB Debugging.",
                    hi = err.message ?: "USB Debugging badal nahi paya.",
                    isError = true
                )
            }
    }

    fun toggleWirelessDebugging() {
        val current = _uiState.value.systemStatus.wirelessDebuggingEnabled ?: false
        if (!_uiState.value.systemStatus.hasWriteSecureSettings) {
            launchShortcutById("usb_wireless_debugging")
            return
        }
        repository.setWirelessDebuggingEnabled(!current)
            .onSuccess {
                refreshSystemState()
                showFeedback(
                    en = if (!current) "Wireless Debugging enabled." else "Wireless Debugging disabled.",
                    hi = if (!current) "Wireless Debugging ON ho gaya." else "Wireless Debugging OFF ho gaya."
                )
            }
            .onFailure { err ->
                showFeedback(
                    en = err.message ?: "Unable to toggle Wireless Debugging.",
                    hi = err.message ?: "Wireless Debugging badal nahi paya.",
                    isError = true
                )
            }
    }

    fun toggleAccessibilityService(serviceId: String, currentlyEnabled: Boolean) {
        if (!_uiState.value.systemStatus.hasWriteSecureSettings) {
            launchShortcutById("accessibility")
            return
        }
        repository.setAccessibilityServiceEnabled(serviceId, !currentlyEnabled)
            .onSuccess {
                refreshSystemState()
                showFeedback(
                    en = if (!currentlyEnabled) "Accessibility service enabled." else "Accessibility service disabled.",
                    hi = if (!currentlyEnabled) "Accessibility service ON ho gayi." else "Accessibility service OFF ho gayi."
                )
            }
            .onFailure { err ->
                showFeedback(
                    en = err.message ?: "Unable to update Accessibility service.",
                    hi = err.message ?: "Accessibility service update nahi ho saki.",
                    isError = true
                )
            }
    }

    fun openAppSettings(packageName: String, target: AppSettingsTarget) {
        repository.openAppSettings(packageName, target)
            .onSuccess {
                showFeedback(
                    en = "Opened system permissions screen for $packageName",
                    hi = "$packageName ki system permission screen khul gayi"
                )
            }
            .onFailure {
                showFeedback(
                    en = "System screen unavailable for $packageName on this TV ROM.",
                    hi = "Is TV firmware par $packageName ke liye yeh screen uplabdh nahi hai.",
                    isError = true
                )
            }
    }

    fun notifyCopiedCommand() {
        showFeedback(
            en = "ADB command copied to clipboard.",
            hi = "ADB command copy ho gaya."
        )
    }

    fun dismissFeedback() {
        _uiState.update { it.copy(feedback = null) }
    }

    private fun showFeedback(en: String, hi: String, isError: Boolean = false) {
        val msg = if (_uiState.value.language == AppLanguage.ENGLISH) en else hi
        _uiState.update { it.copy(feedback = FeedbackBanner(message = msg, isError = isError)) }
    }
}
