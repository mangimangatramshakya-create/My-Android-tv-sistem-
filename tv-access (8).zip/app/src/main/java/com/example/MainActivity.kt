package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.NavDestination
import com.example.ui.components.TvActionButton
import com.example.ui.screens.AppPermissionsScreen
import com.example.ui.screens.HiddenSettingsScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.UnlockGuideScreen
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGrant
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TvAccessTheme
import com.example.viewmodel.TvAccessViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TvAccessTheme {
                TvAccessRoot()
            }
        }
    }
}

@Composable
fun TvAccessRoot(
    viewModel: TvAccessViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    // Refresh real Android OS settings status whenever user returns from System Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshSystemState()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (uiState.destination != NavDestination.OVERVIEW) {
        BackHandler {
            viewModel.selectDestination(NavDestination.OVERVIEW)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianBg, ObsidianSurface, ObsidianBg)
                )
            )
    ) {
        val isWideTvLayout = maxWidth >= 720.dp
        val lang = uiState.language

        if (isWideTvLayout) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(
                        horizontal = if (uiState.systemStatus.isTvDevice) 24.dp else 12.dp,
                        vertical = if (uiState.systemStatus.isTvDevice) 16.dp else 8.dp
                    )
            ) {
                NavigationRail(
                    containerColor = ObsidianCard.copy(alpha = 0.9f),
                    modifier = Modifier
                        .fillMaxHeight()
                        .clip(MaterialTheme.shapes.large)
                        .padding(vertical = 8.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ElectricCyanContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = stringResource(id = R.string.app_name),
                                tint = ElectricCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(0.15f))

                    NavDestination.entries.forEach { dest ->
                        val selected = uiState.destination == dest
                        NavigationRailItem(
                            selected = selected,
                            onClick = { viewModel.selectDestination(dest) },
                            icon = {
                                Icon(
                                    imageVector = destinationIcon(dest),
                                    contentDescription = dest.label.resolve(lang)
                                )
                            },
                            label = {
                                Text(
                                    text = dest.label.resolve(lang),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ElectricCyan,
                                selectedTextColor = ElectricCyan,
                                indicatorColor = ElectricCyanContainer
                            ),
                            modifier = Modifier.testTag("nav_${dest.name.lowercase()}")
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    NavigationRailItem(
                        selected = false,
                        onClick = { viewModel.toggleLanguage() },
                        icon = {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = "Switch Language"
                            )
                        },
                        label = {
                            Text(
                                text = lang.shortLabel,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.testTag("btn_toggle_language_rail")
                    )
                }

                Spacer(modifier = Modifier.width(20.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    TopUtilityHeader(
                        appName = stringResource(id = R.string.app_name),
                        languageLabel = lang.shortLabel,
                        onToggleLanguage = { viewModel.toggleLanguage() }
                    )

                    AnimatedVisibility(visible = uiState.feedback != null) {
                        uiState.feedback?.let { fb ->
                            FeedbackAlertBar(
                                message = fb.message,
                                isError = fb.isError,
                                onDismiss = { viewModel.dismissFeedback() }
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        MainScreenContent(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                    }
                }
            }
        } else {
            Scaffold(
                containerColor = ObsidianBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    NavigationBar(
                        containerColor = ObsidianCard,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        NavDestination.entries.forEach { dest ->
                            val selected = uiState.destination == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectDestination(dest) },
                                icon = {
                                    Icon(
                                        imageVector = destinationIcon(dest),
                                        contentDescription = dest.label.resolve(lang)
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label.resolve(lang),
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricCyan,
                                    selectedTextColor = ElectricCyan,
                                    indicatorColor = ElectricCyanContainer
                                ),
                                modifier = Modifier.testTag("nav_${dest.name.lowercase()}")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    TopUtilityHeader(
                        appName = stringResource(id = R.string.app_name),
                        languageLabel = lang.shortLabel,
                        onToggleLanguage = { viewModel.toggleLanguage() }
                    )

                    AnimatedVisibility(visible = uiState.feedback != null) {
                        uiState.feedback?.let { fb ->
                            FeedbackAlertBar(
                                message = fb.message,
                                isError = fb.isError,
                                onDismiss = { viewModel.dismissFeedback() }
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        MainScreenContent(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopUtilityHeader(
    appName: String,
    languageLabel: String,
    onToggleLanguage: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = appName,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
        }
        TvActionButton(
            label = languageLabel,
            icon = Icons.Filled.Translate,
            onClick = onToggleLanguage,
            testTag = "btn_toggle_language",
            isPrimary = false
        )
    }
}

@Composable
private fun FeedbackAlertBar(
    message: String,
    isError: Boolean,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = MaterialTheme.shapes.small,
        color = if (isError) CoralContainer else EmeraldContainer
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isError) CoralAlert else EmeraldGrant,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_dismiss_feedback")
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Dismiss notification",
                    tint = if (isError) CoralAlert else EmeraldGrant
                )
            }
        }
    }
}

@Composable
private fun MainScreenContent(
    uiState: com.example.viewmodel.TvAccessUiState,
    viewModel: TvAccessViewModel
) {
    when (uiState.destination) {
        NavDestination.OVERVIEW -> OverviewScreen(
            uiState = uiState,
            adbCommand = viewModel.adbGrantCommand,
            onRefresh = { viewModel.refreshSystemState() },
            onLaunchShortcut = { viewModel.launchShortcutById(it) },
            onToggleDeveloperOptions = { viewModel.toggleDeveloperOptions() },
            onToggleUsbDebugging = { viewModel.toggleUsbDebugging() },
            onToggleWirelessDebugging = { viewModel.toggleWirelessDebugging() },
            onNavigate = { viewModel.selectDestination(it) },
            onCopyCommand = { viewModel.notifyCopiedCommand() }
        )

        NavDestination.HIDDEN_SETTINGS -> HiddenSettingsScreen(
            uiState = uiState,
            onLaunchShortcut = { viewModel.launchShortcut(it) },
            onToggleAccessibilityService = { id, enabled ->
                viewModel.toggleAccessibilityService(id, enabled)
            }
        )

        NavDestination.APP_PERMISSIONS -> AppPermissionsScreen(
            uiState = uiState,
            onSelectApp = { viewModel.selectApp(it) },
            onFilterChange = { viewModel.setAppFilter(it) },
            onSearchChange = { viewModel.setAppSearchQuery(it) },
            onRefreshApps = { viewModel.refreshInstalledApps() },
            onOpenAppSettings = { pkg, target ->
                viewModel.openAppSettings(pkg, target)
            }
        )

        NavDestination.UNLOCK_GUIDE -> UnlockGuideScreen(
            uiState = uiState,
            adbCommand = viewModel.adbGrantCommand,
            onLaunchShortcut = { viewModel.launchShortcutById(it) },
            onCopyCommand = { viewModel.notifyCopiedCommand() }
        )
    }
}

private fun destinationIcon(destination: NavDestination): ImageVector = when (destination) {
    NavDestination.OVERVIEW -> Icons.Filled.Dashboard
    NavDestination.HIDDEN_SETTINGS -> Icons.Filled.SettingsSuggest
    NavDestination.APP_PERMISSIONS -> Icons.Filled.Apps
    NavDestination.UNLOCK_GUIDE -> Icons.Filled.MenuBook
}
